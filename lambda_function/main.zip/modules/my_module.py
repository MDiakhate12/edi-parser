def function_hello():
    print("Hello from module.")